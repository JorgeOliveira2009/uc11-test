const { createDefaultPreset } = require("ts-jest");

const tsJestTransformCfg = createDefaultPreset().transform;

/** @type {import("jest").Config} **/
module.exports = {
  testEnvironment: "node",

  transform: {
    ...tsJestTransformCfg,
  },

  
  testMatch: [
    "**/__tests__/**/*.test.ts",
    "**/?(*.)+(spec|test).ts"
  ],

  
  testPathIgnorePatterns: [
    "/node_modules/",
    "/dist/"
  ],

  
  moduleFileExtensions: ["ts", "js", "json"],

  
  clearMocks: true,
};