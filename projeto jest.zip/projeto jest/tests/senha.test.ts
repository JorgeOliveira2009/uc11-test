import { senhaForte } from "../src/senha";

describe("Validação de senha forte", () => {
    
    test("Senha válida (8+ caracteres e com número) deve retornar true", () => {
        expect(senhaForte("abc12345")).toBe(true);
        expect(senhaForte("senhaForte123")).toBe(true);
        expect(senhaForte("12345678")).toBe(true);
    });

    test("Senha com menos de 8 caracteres deve retornar false", () => {
        expect(senhaForte("abc123")).toBe(false);      
        expect(senhaForte("1234567")).toBe(false);     
        expect(senhaForte("curta")).toBe(false);       
    });

    test("Senha sem número deve retornar false", () => {
        expect(senhaForte("abcdefgh")).toBe(false);   
        expect(senhaForte("senhaForte")).toBe(false);  
        expect(senhaForte("!@#$%¨&*")).toBe(false);    
    });

    test("Casos extremos: string vazia e espaços", () => {
        expect(senhaForte("")).toBe(false);            
        expect(senhaForte("        ")).toBe(false);    
        expect(senhaForte("a b c 1")).toBe(false);     
    });
});