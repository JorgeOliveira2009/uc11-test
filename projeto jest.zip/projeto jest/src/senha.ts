
export function senhaForte(senha: string): boolean {
    
    if (senha.length < 8) {
        return false;
    }

    
    const temNumero = /\d/.test(senha);
    if (!temNumero) {
        return false;
    }

    
    return true;
}