
export function teste(n1: number, n2: number): number {
    
    let soma = n1 + n2;
    
    
    console.log(`Soma : ${soma}`);
    
    
    return soma;
}


export function diminuir(n1: number, n2: number) {
    
    let sub = n1 - n2;
    
    
    console.log(`Soma : ${sub}`);
    
    // Retorna o resultado
    return sub;
}


export function mult(n1: number, n2: number) {
    
    let mult = n1 * n2;
    
    
    console.log(`Soma : ${mult}`);
    
    
    return mult;
}


export function div(n1: number, n2: number) {
    
    let div = n1 / n2;
    
    
    console.log(`Soma : ${div}`);
    
    
    return div;
}